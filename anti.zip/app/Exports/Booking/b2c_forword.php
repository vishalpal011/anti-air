<?php

namespace App\Exports\Booking;

use Maatwebsite\Excel\Concerns\FromCollection;

class b2c_forword implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        //
    }
}
