<?php

/*
|--------------------------------------------------------------------------
| Load The Cached Routes
|--------------------------------------------------------------------------
|
| Here we will decode and unserialize the RouteCollection instance that
| holds all of the route information for an application. This allows
| us to instantaneously load the entire route map into the router.
|
*/

app('router')->setCompiledRoutes(
    array (
  'compiled' => 
  array (
    0 => false,
    1 => 
    array (
      '/sanctum/csrf-cookie' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'sanctum.csrf-cookie',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/health-check' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.healthCheck',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/execute-solution' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.executeSolution',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/_ignition/update-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'ignition.updateConfig',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/api/user' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WDKNXJFyLWhQ0o8j',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VK99P2jbXSBn3k8D',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::is8MLSWFmwCEkXV1',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/login-admin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7fqGPffDBWvj2xcb',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forgot-password' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SyQgRlZsx269NSyN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/send-otp' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::5qwmC0gTPM0XkhD5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/logout' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GSsA1W7Z7xQWhfcb',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-awb' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::kt43em9IGyxmBFhy',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-awb-users' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::io367zksHdNvVDLN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/creat-aws-stock' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::euwM0opgDwfzHpQG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/awb-inventory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OCi0DPvLyeku42NE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-awb-inventory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IksO3OTRUKfhtAUg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-awb-inventory' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Brd2VuG2T6N4fJ0T',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-awb-couriers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2d5UIkpu6PIooZgl',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/creat-awb-courier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::CTlROqcPtBBlQOA4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Courier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::800YEFrV6DfDgaeS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/creat-courier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZwYmJ9AC034la3v8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/view-Courier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::whdC56zuInAx4P1W',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-courier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::z22rLfYJhK3pfb2u',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'updateStatus',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-courier' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::i2pwq17uritoHRRu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/courier-allocation' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::KcHS2QcKjrbex7Wz',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-courier-allocated' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Prw0X4hJcA735UBT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-courier-allocateds' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Kvy3BboO4GLKJxSH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-courier-allocated' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::xNCZ4MtTKsw3SUuz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/allocation-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ANS8zX72rQp7nnZ6',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6YAUGV1lzt2ZGWBt',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::AEB593fA7H1VQEIn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::LRB7910zyIUrmX5C',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-country' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::cLsG2xj5T4F9sjjM',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Regions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nTpSrP8LbcRrd4t7',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-regions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::HSO6UyUys0ZO2BVt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-regions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NLnMZfppoPVkC5s4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-regions' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aX9ZscvVmeBjTNwJ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/State' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eZIuD9qYLp128crp',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qn6rTGMwFJA5OsOg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q1r2HrB18htHQVhe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-state' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1BlEnjSP580nXUIr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/City' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MiZyCI3ItdMeFxoO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gW4q9F1ZET8U6apD',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::da4uNnuNI3a1o3lm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-city' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::eq3FYX97q5ijKg8r',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Service-Center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hCam5UblpFhcewe2',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-service-center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q0wMD0PLLql62YfG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-service-center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::a4jdFYzp4J0XaIPA',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-service-center' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0OrkkcqJL3EciV9T',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Pin-Code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::uEnQkMbv9PzIRuTB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-pin-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::PC2IKLrJ14a7fLk2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-pin-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hkDPw5DQXGmq8cDn',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-pin-code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::enYYco3Jqbl6ggAR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Zone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EzoZzWU9PpsHj1xY',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-zone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::t2RqrJslwMkDYR4y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-zone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::H8ahnsJ3PK4SwQZq',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-zone' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vHGGggmQbhkuyXtI',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/search-pin-codes' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2XKXVBmaS28b95ug',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/client' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::VoWy7wxGIBiqy2Fm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-client' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XDoHmCzMgc6DM39h',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-pincode' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::qtDNOPtV6jkzeJ3d',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-pincode2' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::d4a14QE3pnYr5yNh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all-client' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::OArFEV0LaL7hvwIG',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-client' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::8XVd6NYL7BRJK8sv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fbAVKVGYvZggxEvO',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/view-sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::hTzRj2pkDeNl8EIm',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ZLJof4Kz8DchVez1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::90ZT5xRWTinXGR9k',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-sales' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7xRIyE7UjmGF0F47',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/Announcements' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9oAXKLkcqKQjV6EK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-announcements' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nwUoKpSasWGw1Htg',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-post' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1jTPlr2brEXPn4bN',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TfyeRUQPMYbymbgo',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/video-ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::e4dgwhBa957zAaLh',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-video-ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ebkA4k5QHz67mQhu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-video-ad' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::zeknW3iixQSXR2aU',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-video-ads' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::QhG2YajpT11K1vTh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/video-ads-url' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RFdDM1OkDcNLbOao',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-video-ads-url' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::4C8ewoMG4ssfbLPT',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-video-ad-url' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ABPVH6on8btK7v4a',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-video-url' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::GCaO6Ud3zRkn2wsO',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/upload-pin-Code' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::h6H4RXsU5zWPYPIK',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-upload-pin' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FRcr3PJvg8RdnS6m',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-upload-pins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yZBiWGSDM6RbGIKk',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/export-pins' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JTjgcvNR9fC8G9Lm',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P55dMjo8zz0Ryybk',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Z2mwTQU86YJITaD0',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/manual-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MlbR2rb80F9gm4D3',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/view-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::TQHbHGcI6aChCiCE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::obROfAaALH229XfI',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-clients' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::snJAxxtpzoeoWdWR',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::s6zhwCYktB4Lguvh',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-manual-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::7AHrwa2JpDVdQoTE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forword-Booking-B2C' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sg9lzhw9JMWD9STE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/upload-bulkbooking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rAYMHqjPdQk8e9kd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/assign-couriers' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assign-couriers',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-forword-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-forword-booking',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/forword-booking-excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::RG5zDlSHK11zNdx5',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all-b2c-bookings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E8aDGF5vGEZ1ZCmu',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/assign-couriers-b2c' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assign-couriers-b2c',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-booking-b2c-manual' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YnyGtBQKbpWnPSet',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-booking-b2c' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::tdm5SCFTjjSa26KB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-booking-excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J350BXfsvHPrwnoz',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/assign-labels-b2c' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::etjRvHIVj4PYPem1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/scheduled-pickup-b2c' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gU2zEeZNsGNlyAHL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/download_invoice' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dqAL9obroK8vNDc2',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/find-couriers-allocations' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Nk1jelUOEXTY55yt',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/awb-filter-data' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::0o0vHfaIoKloYyIs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/client-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jA2oePmVBNWorRX4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/courier-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dLKmqdHYEAmwF7ii',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/country-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Wvsdo9dtUoyRliHG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/regions-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1CFlQ8fQiz3ImK1W',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/state-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::YZteRFxHwdWE0vSL',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/city-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dObwKevJYRVg9iqw',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/servicecenter-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Cjg9w2kMskEcGi9F',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/pincode-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::gOAMcGhEpMzUmQ8h',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/zone-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::jRt5zQg7xhmM38bV',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/sales-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y6B0GW0VrwhGszr8',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/announcements-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EkolIlRFl2RRInwa',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/videoads-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SUxkOQPMpT0rdvEZ',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/videourl-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6rgBeyFmCPJGW5E4',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/warehouse-data-filter' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::9qQPgKe8lPt2VsqG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/creat-warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UQ1uhkFgyL9GW0Sv',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/view-warehouses' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yNQEAmtZOjddJY1J',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::WlrdLZfPhEHzhu6O',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-warehouse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UL5kjhrQ37LoFdpd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/lable-designs' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::wBou0SFF7d3iLHNN',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/edit-label-4x4' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Ni7kmd7ZYFC0raiE',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/edit-label-4.5x6.25' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JMG5Pp23akflcxsS',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/edit-label-4x6' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BJaUbIXFIiTbtheP',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/default' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::fyydNgWyTYKBXWl6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/lable-setting' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::XGvAKGDrGzp5Lf89',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_sold_by' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::oSTDBpqn8sJgZXyi',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_shippeing' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Q3jkmtuXtnfc7pmx',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_Product' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JNjes9UXcV3WfOao',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_declaration' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SWMpfXE63bCchnvH',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_return_address' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EjDjZ8LFXd62qwfs',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_display_logo' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::ztaqUv8UOREM1GrY',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/active_consignee_mobile' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::aMnN59NgmNgxSqZG',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/email-settings' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::vHtU92n6WVQvxHLB',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/update-mail-config' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::2ujCGaCUxSzRUEHB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reverse-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::EhZvlDsgMUzO5VY6',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reverse-booking-create' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::R0WOscTod3SilKia',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/upload-bulkbooking-reverse' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bGWM9g9CWwLrCY2Y',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all-reverse-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::rQuq9zzMdEgxDjOU',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/assign-couriers-reverse-request' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'assign-couriers-reverse-request',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-reverse-booking' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'delete-reverse-booking',
          ),
          1 => NULL,
          2 => 
          array (
            'DELETE' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/reverse-booking-excel' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A9MCQy2ZsvUiyxcn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/weight-and-EDD' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::bSH5mDoNbDW1PNJ3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/all-apis' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::q80QUbOlZYUTkGfC',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-api-name' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::j7oGUTcM5jaLH6N1',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/apis-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::y4kJv9vNj5Y5g8qf',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-api-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::UqPo6ISSq9a20Mks',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/apis-comments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1mCB9BEXoenJpwn3',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/get-apis-status' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MQFnuqsMslU8qZEd',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-courier-comments' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::NHi0bP4tteiuyP0E',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/client-kyc-reject' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::yxa2MvMrEirlDtE5',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/client-kyc-approve' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::MW9ftd37DBjKhlUe',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/courier-service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::P142mmDGxrtUFOar',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-courier-rates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::J4BnYvLElSNMYRDn',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/upload-courier-rate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::FPxefjAztfsDrHhr',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/view-courier-rates' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::IynR7AsIFkgfjrDq',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-courier-rate' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::nKOWxy3jHJgs9TaB',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/create-courier-service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::A3TG5v1jgPmjPZKu',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/delete-courier-service' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::E5CdXCTBPsQhRNLE',
          ),
          1 => NULL,
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
      '/errors/404' => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::noUgUXXAmFFwqlp4',
          ),
          1 => NULL,
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => false,
          6 => NULL,
        ),
      ),
    ),
    2 => 
    array (
      0 => '{^(?|/download\\-awbcodes/([^/]++)(*:35)|/edit\\-(?|courier(?|/([^/]++)(*:71)|\\-rate/([^/]++)(*:93))|warehouse/([^/]++)(*:119))|/view\\-(?|client\\-details/([^/]++)(*:162)|bookings(?|/([^/]++)(*:190)|\\-b2c/([^/]++)(*:212)))|/client\\-(?|update/([^/]++)(*:249)|docs\\-update/([^/]++)(*:278)|company\\-docs\\-update/([^/]++)(*:316))|/rebooking/([^/]++)(*:344)|/update\\-courier\\-(?|rate/([^/]++)(*:386)|service/([^/]++)(*:410)))/?$}sDu',
    ),
    3 => 
    array (
      35 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::iSzLd4dkc2qPHw6h',
          ),
          1 => 
          array (
            0 => 'user_id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      71 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::6Lq281sOq8ZtrsNt',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      93 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Y8kNJxFFFlGGEfPR',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      119 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::JX25JG8uELocthtW',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      162 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::1k2wmDfrorCXxXps',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      190 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::O5bLGTvTfiDpcJga',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      212 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::dptDKjIAhsAzOL8x',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      249 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::BIpOsAJB4AdCPmCb',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      278 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::pXG681NuNkWWkk0D',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      316 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::lJMQsTJ1yiMxVQRr',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      344 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Dsteqqxz3EGg4ot2',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'GET' => 0,
            'HEAD' => 1,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      386 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::Sslx04bHXip8hHw8',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
      ),
      410 => 
      array (
        0 => 
        array (
          0 => 
          array (
            '_route' => 'generated::SrrCQG7iVVsG9cDq',
          ),
          1 => 
          array (
            0 => 'id',
          ),
          2 => 
          array (
            'POST' => 0,
          ),
          3 => NULL,
          4 => false,
          5 => true,
          6 => NULL,
        ),
        1 => 
        array (
          0 => NULL,
          1 => NULL,
          2 => NULL,
          3 => NULL,
          4 => false,
          5 => false,
          6 => 0,
        ),
      ),
    ),
    4 => NULL,
  ),
  'attributes' => 
  array (
    'sanctum.csrf-cookie' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'sanctum/csrf-cookie',
      'action' => 
      array (
        'uses' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'controller' => 'Laravel\\Sanctum\\Http\\Controllers\\CsrfCookieController@show',
        'namespace' => NULL,
        'prefix' => 'sanctum',
        'where' => 
        array (
        ),
        'middleware' => 
        array (
          0 => 'web',
        ),
        'as' => 'sanctum.csrf-cookie',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.healthCheck' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '_ignition/health-check',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\HealthCheckController',
        'as' => 'ignition.healthCheck',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.executeSolution' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/execute-solution',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\ExecuteSolutionController',
        'as' => 'ignition.executeSolution',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'ignition.updateConfig' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => '_ignition/update-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'Spatie\\LaravelIgnition\\Http\\Middleware\\RunnableSolutionsEnabled',
        ),
        'uses' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController@__invoke',
        'controller' => 'Spatie\\LaravelIgnition\\Http\\Controllers\\UpdateConfigController',
        'as' => 'ignition.updateConfig',
        'namespace' => NULL,
        'prefix' => '_ignition',
        'where' => 
        array (
        ),
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WDKNXJFyLWhQ0o8j' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'api/user',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'api',
          1 => 'auth:sanctum',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:77:"function (\\Illuminate\\Http\\Request $request) {
    return $request->user();
}";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"00000000000009680000000000000000";}}',
        'namespace' => NULL,
        'prefix' => 'api',
        'where' => 
        array (
        ),
        'as' => 'generated::WDKNXJFyLWhQ0o8j',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VK99P2jbXSBn3k8D' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => '/',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@index',
        'controller' => 'App\\Http\\Controllers\\Controller@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VK99P2jbXSBn3k8D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::is8MLSWFmwCEkXV1' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'login',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@index',
        'controller' => 'App\\Http\\Controllers\\AdminController@index',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::is8MLSWFmwCEkXV1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7fqGPffDBWvj2xcb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'login-admin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@admin_login',
        'controller' => 'App\\Http\\Controllers\\AdminController@admin_login',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7fqGPffDBWvj2xcb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SyQgRlZsx269NSyN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forgot-password',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@forgot_pass',
        'controller' => 'App\\Http\\Controllers\\AdminController@forgot_pass',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SyQgRlZsx269NSyN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::5qwmC0gTPM0XkhD5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'send-otp',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'guest',
        ),
        'uses' => 'App\\Http\\Controllers\\AdminController@send_otp',
        'controller' => 'App\\Http\\Controllers\\AdminController@send_otp',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::5qwmC0gTPM0XkhD5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GSsA1W7Z7xQWhfcb' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'logout',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@logout',
        'controller' => 'App\\Http\\Controllers\\Controller@logout',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GSsA1W7Z7xQWhfcb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::kt43em9IGyxmBFhy' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'create-awb',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@create_awb',
        'controller' => 'App\\Http\\Controllers\\Controller@create_awb',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::kt43em9IGyxmBFhy',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::io367zksHdNvVDLN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'get-awb-users',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@show_users',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@show_users',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::io367zksHdNvVDLN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::euwM0opgDwfzHpQG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'creat-aws-stock',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@create',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::euwM0opgDwfzHpQG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OCi0DPvLyeku42NE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'awb-inventory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@view_inventory',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@view_inventory',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OCi0DPvLyeku42NE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IksO3OTRUKfhtAUg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-awb-inventory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@update_awb_inventory',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@update_awb_inventory',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IksO3OTRUKfhtAUg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Brd2VuG2T6N4fJ0T' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-awb-inventory',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@delete_awb_inventory',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@delete_awb_inventory',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Brd2VuG2T6N4fJ0T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::iSzLd4dkc2qPHw6h' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'download-awbcodes/{user_id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@download_awbcodes',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@download_awbcodes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::iSzLd4dkc2qPHw6h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2d5UIkpu6PIooZgl' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'create-awb-couriers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@create_awb_couriers',
        'controller' => 'App\\Http\\Controllers\\Controller@create_awb_couriers',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2d5UIkpu6PIooZgl',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::CTlROqcPtBBlQOA4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'creat-awb-courier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@creat_awb_courier',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@creat_awb_courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::CTlROqcPtBBlQOA4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::800YEFrV6DfDgaeS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Courier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@Courier',
        'controller' => 'App\\Http\\Controllers\\Controller@Courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::800YEFrV6DfDgaeS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZwYmJ9AC034la3v8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'creat-courier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@create_courier',
        'controller' => 'App\\Http\\Controllers\\CourierController@create_courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZwYmJ9AC034la3v8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::whdC56zuInAx4P1W' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-Courier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@view_Courier',
        'controller' => 'App\\Http\\Controllers\\CourierController@view_Courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::whdC56zuInAx4P1W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6Lq281sOq8ZtrsNt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-courier/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@edit_Courier',
        'controller' => 'App\\Http\\Controllers\\CourierController@edit_Courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6Lq281sOq8ZtrsNt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::z22rLfYJhK3pfb2u' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-courier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@update_Courier',
        'controller' => 'App\\Http\\Controllers\\CourierController@update_Courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::z22rLfYJhK3pfb2u',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'updateStatus' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@updateStatus',
        'controller' => 'App\\Http\\Controllers\\CourierController@updateStatus',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'updateStatus',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::i2pwq17uritoHRRu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-courier',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@delete_courier',
        'controller' => 'App\\Http\\Controllers\\CourierController@delete_courier',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::i2pwq17uritoHRRu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::KcHS2QcKjrbex7Wz' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'courier-allocation',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@courier_allocation',
        'controller' => 'App\\Http\\Controllers\\CourierController@courier_allocation',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::KcHS2QcKjrbex7Wz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Prw0X4hJcA735UBT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-courier-allocated',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@create_courier_allocated',
        'controller' => 'App\\Http\\Controllers\\CourierController@create_courier_allocated',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Prw0X4hJcA735UBT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Kvy3BboO4GLKJxSH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-courier-allocateds',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@update_courier_allocateds',
        'controller' => 'App\\Http\\Controllers\\CourierController@update_courier_allocateds',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Kvy3BboO4GLKJxSH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::xNCZ4MtTKsw3SUuz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-courier-allocated',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@delete_courier_allocated',
        'controller' => 'App\\Http\\Controllers\\CourierController@delete_courier_allocated',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::xNCZ4MtTKsw3SUuz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ANS8zX72rQp7nnZ6' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'allocation-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@allocation_status',
        'controller' => 'App\\Http\\Controllers\\CourierController@allocation_status',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ANS8zX72rQp7nnZ6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6YAUGV1lzt2ZGWBt' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@Country',
        'controller' => 'App\\Http\\Controllers\\Controller@Country',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6YAUGV1lzt2ZGWBt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::AEB593fA7H1VQEIn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_country',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_country',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::AEB593fA7H1VQEIn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::LRB7910zyIUrmX5C' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_country',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_country',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::LRB7910zyIUrmX5C',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::cLsG2xj5T4F9sjjM' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-country',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_country',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_country',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::cLsG2xj5T4F9sjjM',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nTpSrP8LbcRrd4t7' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Regions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@Regions',
        'controller' => 'App\\Http\\Controllers\\Controller@Regions',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nTpSrP8LbcRrd4t7',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::HSO6UyUys0ZO2BVt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-regions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_regions',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_regions',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::HSO6UyUys0ZO2BVt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NLnMZfppoPVkC5s4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-regions ',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_regions',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_regions',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NLnMZfppoPVkC5s4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aX9ZscvVmeBjTNwJ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-regions',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_regions',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_regions',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::aX9ZscvVmeBjTNwJ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eZIuD9qYLp128crp' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'State',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@State',
        'controller' => 'App\\Http\\Controllers\\Controller@State',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eZIuD9qYLp128crp',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qn6rTGMwFJA5OsOg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_state',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_state',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qn6rTGMwFJA5OsOg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q1r2HrB18htHQVhe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_state',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_state',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::q1r2HrB18htHQVhe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1BlEnjSP580nXUIr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-state',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_state',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_state',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1BlEnjSP580nXUIr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MiZyCI3ItdMeFxoO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'City',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@City',
        'controller' => 'App\\Http\\Controllers\\Controller@City',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MiZyCI3ItdMeFxoO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gW4q9F1ZET8U6apD' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_city',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_city',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gW4q9F1ZET8U6apD',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::da4uNnuNI3a1o3lm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_city',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_city',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::da4uNnuNI3a1o3lm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::eq3FYX97q5ijKg8r' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-city',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_city',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_city',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::eq3FYX97q5ijKg8r',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hCam5UblpFhcewe2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Service-Center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@service_center',
        'controller' => 'App\\Http\\Controllers\\Controller@service_center',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hCam5UblpFhcewe2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q0wMD0PLLql62YfG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-service-center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_service_center',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_service_center',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::q0wMD0PLLql62YfG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::a4jdFYzp4J0XaIPA' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-service-center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_service_center',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_service_center',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::a4jdFYzp4J0XaIPA',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0OrkkcqJL3EciV9T' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-service-center',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_service_center',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_service_center',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0OrkkcqJL3EciV9T',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::uEnQkMbv9PzIRuTB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Pin-Code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@pin_code',
        'controller' => 'App\\Http\\Controllers\\Controller@pin_code',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::uEnQkMbv9PzIRuTB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::PC2IKLrJ14a7fLk2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-pin-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_pin_code',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_pin_code',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::PC2IKLrJ14a7fLk2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hkDPw5DQXGmq8cDn' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-pin-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_pin_code',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_pin_code',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hkDPw5DQXGmq8cDn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::enYYco3Jqbl6ggAR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-pin-code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_pin_code',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_pin_code',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::enYYco3Jqbl6ggAR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EzoZzWU9PpsHj1xY' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Zone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@Zone',
        'controller' => 'App\\Http\\Controllers\\Controller@Zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EzoZzWU9PpsHj1xY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::t2RqrJslwMkDYR4y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-zone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@create_zone',
        'controller' => 'App\\Http\\Controllers\\LocationController@create_zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::t2RqrJslwMkDYR4y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::H8ahnsJ3PK4SwQZq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-zone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@update_zone',
        'controller' => 'App\\Http\\Controllers\\LocationController@update_zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::H8ahnsJ3PK4SwQZq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vHGGggmQbhkuyXtI' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-zone',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_zone',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_zone',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vHGGggmQbhkuyXtI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2XKXVBmaS28b95ug' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'search-pin-codes',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@search_pin_codes',
        'controller' => 'App\\Http\\Controllers\\LocationController@search_pin_codes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2XKXVBmaS28b95ug',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::VoWy7wxGIBiqy2Fm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'client',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@client',
        'controller' => 'App\\Http\\Controllers\\Controller@client',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::VoWy7wxGIBiqy2Fm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XDoHmCzMgc6DM39h' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-client',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@create_client',
        'controller' => 'App\\Http\\Controllers\\ClientController@create_client',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XDoHmCzMgc6DM39h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::qtDNOPtV6jkzeJ3d' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'get-pincode',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@get_pincode_data',
        'controller' => 'App\\Http\\Controllers\\ClientController@get_pincode_data',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::qtDNOPtV6jkzeJ3d',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::d4a14QE3pnYr5yNh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'get-pincode2',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@get_pincode_data2',
        'controller' => 'App\\Http\\Controllers\\ClientController@get_pincode_data2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::d4a14QE3pnYr5yNh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::OArFEV0LaL7hvwIG' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all-client',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@all_client',
        'controller' => 'App\\Http\\Controllers\\ClientController@all_client',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::OArFEV0LaL7hvwIG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1k2wmDfrorCXxXps' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-client-details/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@view_client',
        'controller' => 'App\\Http\\Controllers\\ClientController@view_client',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1k2wmDfrorCXxXps',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::8XVd6NYL7BRJK8sv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-client',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@delete_client',
        'controller' => 'App\\Http\\Controllers\\ClientController@delete_client',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::8XVd6NYL7BRJK8sv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BIpOsAJB4AdCPmCb' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'client-update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@client_update',
        'controller' => 'App\\Http\\Controllers\\ClientController@client_update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BIpOsAJB4AdCPmCb',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::pXG681NuNkWWkk0D' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'client-docs-update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@client_docs_update',
        'controller' => 'App\\Http\\Controllers\\ClientController@client_docs_update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::pXG681NuNkWWkk0D',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::lJMQsTJ1yiMxVQRr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'client-company-docs-update/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@company_docs_update',
        'controller' => 'App\\Http\\Controllers\\ClientController@company_docs_update',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::lJMQsTJ1yiMxVQRr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fbAVKVGYvZggxEvO' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@Sales',
        'controller' => 'App\\Http\\Controllers\\Controller@Sales',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fbAVKVGYvZggxEvO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::hTzRj2pkDeNl8EIm' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'view-sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\SalesLeadController@view_sales',
        'controller' => 'App\\Http\\Controllers\\SalesLeadController@view_sales',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::hTzRj2pkDeNl8EIm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ZLJof4Kz8DchVez1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\SalesLeadController@create_sales',
        'controller' => 'App\\Http\\Controllers\\SalesLeadController@create_sales',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ZLJof4Kz8DchVez1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::90ZT5xRWTinXGR9k' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\SalesLeadController@update_sales',
        'controller' => 'App\\Http\\Controllers\\SalesLeadController@update_sales',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::90ZT5xRWTinXGR9k',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7xRIyE7UjmGF0F47' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-sales',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\SalesLeadController@delete_sales',
        'controller' => 'App\\Http\\Controllers\\SalesLeadController@delete_sales',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7xRIyE7UjmGF0F47',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9oAXKLkcqKQjV6EK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'Announcements',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@Announcements',
        'controller' => 'App\\Http\\Controllers\\Controller@Announcements',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9oAXKLkcqKQjV6EK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nwUoKpSasWGw1Htg' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-announcements',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@create_announcements',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@create_announcements',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nwUoKpSasWGw1Htg',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1jTPlr2brEXPn4bN' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-post',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@update_post',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@update_post',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1jTPlr2brEXPn4bN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TfyeRUQPMYbymbgo' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@delete_ad',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@delete_ad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TfyeRUQPMYbymbgo',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::e4dgwhBa957zAaLh' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'video-ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@video_ad',
        'controller' => 'App\\Http\\Controllers\\Controller@video_ad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::e4dgwhBa957zAaLh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ebkA4k5QHz67mQhu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-video-ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@create_video_ad',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@create_video_ad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ebkA4k5QHz67mQhu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::zeknW3iixQSXR2aU' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-video-ad',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@update_video_ad',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@update_video_ad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::zeknW3iixQSXR2aU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::QhG2YajpT11K1vTh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-video-ads',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@delete_video_ad',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@delete_video_ad',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::QhG2YajpT11K1vTh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RFdDM1OkDcNLbOao' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'video-ads-url',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@video_ad_url',
        'controller' => 'App\\Http\\Controllers\\Controller@video_ad_url',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RFdDM1OkDcNLbOao',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::4C8ewoMG4ssfbLPT' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-video-ads-url',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@create_video_ad_url',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@create_video_ad_url',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::4C8ewoMG4ssfbLPT',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ABPVH6on8btK7v4a' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-video-ad-url',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@update_video_ad_url',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@update_video_ad_url',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ABPVH6on8btK7v4a',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::GCaO6Ud3zRkn2wsO' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-video-url',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@delete_video_ad_url',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@delete_video_ad_url',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::GCaO6Ud3zRkn2wsO',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::h6H4RXsU5zWPYPIK' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'upload-pin-Code',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@upload_pin_code',
        'controller' => 'App\\Http\\Controllers\\Controller@upload_pin_code',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::h6H4RXsU5zWPYPIK',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FRcr3PJvg8RdnS6m' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-upload-pin',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@upload_pin',
        'controller' => 'App\\Http\\Controllers\\LocationController@upload_pin',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FRcr3PJvg8RdnS6m',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yZBiWGSDM6RbGIKk' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'delete-upload-pins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@delete_pincodes',
        'controller' => 'App\\Http\\Controllers\\LocationController@delete_pincodes',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yZBiWGSDM6RbGIKk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JTjgcvNR9fC8G9Lm' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'export-pins',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@export_pins',
        'controller' => 'App\\Http\\Controllers\\LocationController@export_pins',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JTjgcvNR9fC8G9Lm',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P55dMjo8zz0Ryybk' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@warehouse',
        'controller' => 'App\\Http\\Controllers\\Controller@warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::P55dMjo8zz0Ryybk',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Z2mwTQU86YJITaD0' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@booking',
        'controller' => 'App\\Http\\Controllers\\Controller@booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Z2mwTQU86YJITaD0',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MlbR2rb80F9gm4D3' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'manual-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@manual_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@manual_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MlbR2rb80F9gm4D3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::TQHbHGcI6aChCiCE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@view_booking',
        'controller' => 'App\\Http\\Controllers\\Controller@view_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::TQHbHGcI6aChCiCE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::obROfAaALH229XfI' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@all_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@all_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::obROfAaALH229XfI',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::snJAxxtpzoeoWdWR' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'get-clients',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@get_client',
        'controller' => 'App\\Http\\Controllers\\BookingController@get_client',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::snJAxxtpzoeoWdWR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::s6zhwCYktB4Lguvh' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'get-warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@get_warehouse',
        'controller' => 'App\\Http\\Controllers\\BookingController@get_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::s6zhwCYktB4Lguvh',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Dsteqqxz3EGg4ot2' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'rebooking/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@rebooking',
        'controller' => 'App\\Http\\Controllers\\BookingController@rebooking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Dsteqqxz3EGg4ot2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::7AHrwa2JpDVdQoTE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-manual-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@update_manual_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@update_manual_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::7AHrwa2JpDVdQoTE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sg9lzhw9JMWD9STE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forword-Booking-B2C',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@forword_Booking_B2C',
        'controller' => 'App\\Http\\Controllers\\BookingController@forword_Booking_B2C',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Sg9lzhw9JMWD9STE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rAYMHqjPdQk8e9kd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'upload-bulkbooking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@upload_bulkbooking',
        'controller' => 'App\\Http\\Controllers\\BookingController@upload_bulkbooking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rAYMHqjPdQk8e9kd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assign-couriers' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'assign-couriers',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@assign_couriers',
        'controller' => 'App\\Http\\Controllers\\BookingController@assign_couriers',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'assign-couriers',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::O5bLGTvTfiDpcJga' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-bookings/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@view_bookings',
        'controller' => 'App\\Http\\Controllers\\BookingController@view_bookings',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::O5bLGTvTfiDpcJga',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-forword-booking' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'delete-forword-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@delete_forword_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@delete_forword_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'delete-forword-booking',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::RG5zDlSHK11zNdx5' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'forword-booking-excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@all_forword_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@all_forword_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::RG5zDlSHK11zNdx5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E8aDGF5vGEZ1ZCmu' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all-b2c-bookings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@all_b2c_bookings',
        'controller' => 'App\\Http\\Controllers\\BookingController@all_b2c_bookings',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::E8aDGF5vGEZ1ZCmu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assign-couriers-b2c' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'assign-couriers-b2c',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@assign_couriers_b2c',
        'controller' => 'App\\Http\\Controllers\\BookingController@assign_couriers_b2c',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'assign-couriers-b2c',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dptDKjIAhsAzOL8x' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-bookings-b2c/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@view_bookings_b2c',
        'controller' => 'App\\Http\\Controllers\\BookingController@view_bookings_b2c',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dptDKjIAhsAzOL8x',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YnyGtBQKbpWnPSet' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-booking-b2c-manual',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@create_booking_b2c_manual',
        'controller' => 'App\\Http\\Controllers\\BookingController@create_booking_b2c_manual',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YnyGtBQKbpWnPSet',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::tdm5SCFTjjSa26KB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-booking-b2c',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@update_bookings_b2c',
        'controller' => 'App\\Http\\Controllers\\BookingController@update_bookings_b2c',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::tdm5SCFTjjSa26KB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J350BXfsvHPrwnoz' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-booking-excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@update_bookings_excel',
        'controller' => 'App\\Http\\Controllers\\BookingController@update_bookings_excel',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::J350BXfsvHPrwnoz',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::etjRvHIVj4PYPem1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'assign-labels-b2c',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@assign_labels_b2c',
        'controller' => 'App\\Http\\Controllers\\BookingController@assign_labels_b2c',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::etjRvHIVj4PYPem1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gU2zEeZNsGNlyAHL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'scheduled-pickup-b2c',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@scheduled_pickup_b2c',
        'controller' => 'App\\Http\\Controllers\\BookingController@scheduled_pickup_b2c',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gU2zEeZNsGNlyAHL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dqAL9obroK8vNDc2' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'download_invoice',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@download_invoice',
        'controller' => 'App\\Http\\Controllers\\BookingController@download_invoice',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dqAL9obroK8vNDc2',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Nk1jelUOEXTY55yt' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'find-couriers-allocations',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@find_couriers_allocations',
        'controller' => 'App\\Http\\Controllers\\BookingController@find_couriers_allocations',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Nk1jelUOEXTY55yt',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::0o0vHfaIoKloYyIs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'awb-filter-data',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AirWayStockController@awb_filter_data',
        'controller' => 'App\\Http\\Controllers\\AirWayStockController@awb_filter_data',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::0o0vHfaIoKloYyIs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jA2oePmVBNWorRX4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'client-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@client_data_filter',
        'controller' => 'App\\Http\\Controllers\\ClientController@client_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jA2oePmVBNWorRX4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dLKmqdHYEAmwF7ii' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'courier-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\CourierController@courier_data_filter',
        'controller' => 'App\\Http\\Controllers\\CourierController@courier_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dLKmqdHYEAmwF7ii',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Wvsdo9dtUoyRliHG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'country-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@country_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@country_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Wvsdo9dtUoyRliHG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1CFlQ8fQiz3ImK1W' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'regions-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@regions_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@regions_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1CFlQ8fQiz3ImK1W',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::YZteRFxHwdWE0vSL' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'state-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@state_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@state_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::YZteRFxHwdWE0vSL',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::dObwKevJYRVg9iqw' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'city-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@city_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@city_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::dObwKevJYRVg9iqw',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Cjg9w2kMskEcGi9F' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'servicecenter-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@servicecenter_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@servicecenter_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Cjg9w2kMskEcGi9F',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::gOAMcGhEpMzUmQ8h' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'pincode-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@pincode_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@pincode_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::gOAMcGhEpMzUmQ8h',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::jRt5zQg7xhmM38bV' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'zone-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LocationController@zone_data_filter',
        'controller' => 'App\\Http\\Controllers\\LocationController@zone_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::jRt5zQg7xhmM38bV',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y6B0GW0VrwhGszr8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'sales-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\SalesLeadController@sales_data_filter',
        'controller' => 'App\\Http\\Controllers\\SalesLeadController@sales_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Y6B0GW0VrwhGszr8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EkolIlRFl2RRInwa' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'announcements-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@announcements_data_filter',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@announcements_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EkolIlRFl2RRInwa',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SUxkOQPMpT0rdvEZ' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'videoads-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@videoads_data_filter',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@videoads_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SUxkOQPMpT0rdvEZ',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::6rgBeyFmCPJGW5E4' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'videourl-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\AnnouncementController@videourl_data_filter',
        'controller' => 'App\\Http\\Controllers\\AnnouncementController@videourl_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::6rgBeyFmCPJGW5E4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::9qQPgKe8lPt2VsqG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'warehouse-data-filter',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\warehouseController@warehouse_data_filter',
        'controller' => 'App\\Http\\Controllers\\warehouseController@warehouse_data_filter',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::9qQPgKe8lPt2VsqG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UQ1uhkFgyL9GW0Sv' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'creat-warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\warehouseController@creat_warehouse',
        'controller' => 'App\\Http\\Controllers\\warehouseController@creat_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UQ1uhkFgyL9GW0Sv',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yNQEAmtZOjddJY1J' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-warehouses',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\warehouseController@view_warehouses',
        'controller' => 'App\\Http\\Controllers\\warehouseController@view_warehouses',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yNQEAmtZOjddJY1J',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JX25JG8uELocthtW' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-warehouse/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\warehouseController@edit_warehouse',
        'controller' => 'App\\Http\\Controllers\\warehouseController@edit_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JX25JG8uELocthtW',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::WlrdLZfPhEHzhu6O' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\warehouseController@update_warehouse',
        'controller' => 'App\\Http\\Controllers\\warehouseController@update_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::WlrdLZfPhEHzhu6O',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UL5kjhrQ37LoFdpd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-warehouse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\warehouseController@delete_warehouse',
        'controller' => 'App\\Http\\Controllers\\warehouseController@delete_warehouse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UL5kjhrQ37LoFdpd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::wBou0SFF7d3iLHNN' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'lable-designs',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@defualt',
        'controller' => 'App\\Http\\Controllers\\LabelController@defualt',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::wBou0SFF7d3iLHNN',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Ni7kmd7ZYFC0raiE' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-label-4x4',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@edit_label',
        'controller' => 'App\\Http\\Controllers\\LabelController@edit_label',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Ni7kmd7ZYFC0raiE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JMG5Pp23akflcxsS' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-label-4.5x6.25',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@edit_label2',
        'controller' => 'App\\Http\\Controllers\\LabelController@edit_label2',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JMG5Pp23akflcxsS',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::BJaUbIXFIiTbtheP' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-label-4x6',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@edit_label3',
        'controller' => 'App\\Http\\Controllers\\LabelController@edit_label3',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::BJaUbIXFIiTbtheP',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::fyydNgWyTYKBXWl6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'default',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@edit_label4',
        'controller' => 'App\\Http\\Controllers\\LabelController@edit_label4',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::fyydNgWyTYKBXWl6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::XGvAKGDrGzp5Lf89' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'lable-setting',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@lable_setting',
        'controller' => 'App\\Http\\Controllers\\LabelController@lable_setting',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::XGvAKGDrGzp5Lf89',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::oSTDBpqn8sJgZXyi' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_sold_by',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_sold_by',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_sold_by',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::oSTDBpqn8sJgZXyi',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Q3jkmtuXtnfc7pmx' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_shippeing',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_shippeing',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_shippeing',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Q3jkmtuXtnfc7pmx',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::JNjes9UXcV3WfOao' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_Product',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_Product',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_Product',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::JNjes9UXcV3WfOao',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SWMpfXE63bCchnvH' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_declaration',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_declaration',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_declaration',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SWMpfXE63bCchnvH',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EjDjZ8LFXd62qwfs' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_return_address',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_return_address',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_return_address',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EjDjZ8LFXd62qwfs',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::ztaqUv8UOREM1GrY' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_display_logo',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_display_logo',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_display_logo',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::ztaqUv8UOREM1GrY',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::aMnN59NgmNgxSqZG' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'active_consignee_mobile',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\LabelController@active_consignee_mobile',
        'controller' => 'App\\Http\\Controllers\\LabelController@active_consignee_mobile',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::aMnN59NgmNgxSqZG',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::vHtU92n6WVQvxHLB' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'email-settings',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@email_settings',
        'controller' => 'App\\Http\\Controllers\\Controller@email_settings',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::vHtU92n6WVQvxHLB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::2ujCGaCUxSzRUEHB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-mail-config',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\Controller@update_mail_config',
        'controller' => 'App\\Http\\Controllers\\Controller@update_mail_config',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::2ujCGaCUxSzRUEHB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::EhZvlDsgMUzO5VY6' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reverse-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@reverse_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@reverse_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::EhZvlDsgMUzO5VY6',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::R0WOscTod3SilKia' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'reverse-booking-create',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@reverse_booking_create',
        'controller' => 'App\\Http\\Controllers\\BookingController@reverse_booking_create',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::R0WOscTod3SilKia',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bGWM9g9CWwLrCY2Y' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'upload-bulkbooking-reverse',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@upload_bulkbooking_reverse',
        'controller' => 'App\\Http\\Controllers\\BookingController@upload_bulkbooking_reverse',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bGWM9g9CWwLrCY2Y',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::rQuq9zzMdEgxDjOU' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all-reverse-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@all_reverse_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@all_reverse_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::rQuq9zzMdEgxDjOU',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'assign-couriers-reverse-request' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'assign-couriers-reverse-request',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@assign_couriers_reverse_request',
        'controller' => 'App\\Http\\Controllers\\BookingController@assign_couriers_reverse_request',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'assign-couriers-reverse-request',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'delete-reverse-booking' => 
    array (
      'methods' => 
      array (
        0 => 'DELETE',
      ),
      'uri' => 'delete-reverse-booking',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@delete_reverse_booking',
        'controller' => 'App\\Http\\Controllers\\BookingController@delete_reverse_booking',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'delete-reverse-booking',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A9MCQy2ZsvUiyxcn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'reverse-booking-excel',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\BookingController@reverse_booking_excel',
        'controller' => 'App\\Http\\Controllers\\BookingController@reverse_booking_excel',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::A9MCQy2ZsvUiyxcn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::bSH5mDoNbDW1PNJ3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'weight-and-EDD',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\WeightController@weight_and_EDD',
        'controller' => 'App\\Http\\Controllers\\WeightController@weight_and_EDD',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::bSH5mDoNbDW1PNJ3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::q80QUbOlZYUTkGfC' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'all-apis',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@all_api',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@all_api',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::q80QUbOlZYUTkGfC',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::j7oGUTcM5jaLH6N1' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-api-name',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@create_api_name',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@create_api_name',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::j7oGUTcM5jaLH6N1',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::y4kJv9vNj5Y5g8qf' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'apis-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@apis_status',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@apis_status',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::y4kJv9vNj5Y5g8qf',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::UqPo6ISSq9a20Mks' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-api-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@create_api_status',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@create_api_status',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::UqPo6ISSq9a20Mks',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::1mCB9BEXoenJpwn3' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'apis-comments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@api_comments',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@api_comments',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::1mCB9BEXoenJpwn3',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MQFnuqsMslU8qZEd' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'get-apis-status',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@get_apis_status',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@get_apis_status',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MQFnuqsMslU8qZEd',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::NHi0bP4tteiuyP0E' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-courier-comments',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ApimasterController@create_courier_comments',
        'controller' => 'App\\Http\\Controllers\\ApimasterController@create_courier_comments',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::NHi0bP4tteiuyP0E',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::yxa2MvMrEirlDtE5' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'client-kyc-reject',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@client_kyc_reject',
        'controller' => 'App\\Http\\Controllers\\ClientController@client_kyc_reject',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::yxa2MvMrEirlDtE5',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::MW9ftd37DBjKhlUe' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'client-kyc-approve',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\ClientController@client_kyc_approve',
        'controller' => 'App\\Http\\Controllers\\ClientController@client_kyc_approve',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::MW9ftd37DBjKhlUe',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::P142mmDGxrtUFOar' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'courier-service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@courier_service',
        'controller' => 'App\\Http\\Controllers\\RateCardController@courier_service',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::P142mmDGxrtUFOar',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::J4BnYvLElSNMYRDn' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'create-courier-rates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@create_courier_rates',
        'controller' => 'App\\Http\\Controllers\\RateCardController@create_courier_rates',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::J4BnYvLElSNMYRDn',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::FPxefjAztfsDrHhr' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'upload-courier-rate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@upload_courier_rate',
        'controller' => 'App\\Http\\Controllers\\RateCardController@upload_courier_rate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::FPxefjAztfsDrHhr',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::IynR7AsIFkgfjrDq' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'view-courier-rates',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@view_courier_rates',
        'controller' => 'App\\Http\\Controllers\\RateCardController@view_courier_rates',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::IynR7AsIFkgfjrDq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Y8kNJxFFFlGGEfPR' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'edit-courier-rate/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@edit_courier_rate',
        'controller' => 'App\\Http\\Controllers\\RateCardController@edit_courier_rate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Y8kNJxFFFlGGEfPR',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::Sslx04bHXip8hHw8' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-courier-rate/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@update_courier_rate',
        'controller' => 'App\\Http\\Controllers\\RateCardController@update_courier_rate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::Sslx04bHXip8hHw8',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::nKOWxy3jHJgs9TaB' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-courier-rate',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@delete_courier_rate',
        'controller' => 'App\\Http\\Controllers\\RateCardController@delete_courier_rate',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::nKOWxy3jHJgs9TaB',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::A3TG5v1jgPmjPZKu' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'create-courier-service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@create_courier_service',
        'controller' => 'App\\Http\\Controllers\\RateCardController@create_courier_service',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::A3TG5v1jgPmjPZKu',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::SrrCQG7iVVsG9cDq' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'update-courier-service/{id}',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@update_courier_service',
        'controller' => 'App\\Http\\Controllers\\RateCardController@update_courier_service',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::SrrCQG7iVVsG9cDq',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::E5CdXCTBPsQhRNLE' => 
    array (
      'methods' => 
      array (
        0 => 'POST',
      ),
      'uri' => 'delete-courier-service',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'App\\Http\\Controllers\\RateCardController@delete_courier_service',
        'controller' => 'App\\Http\\Controllers\\RateCardController@delete_courier_service',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::E5CdXCTBPsQhRNLE',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
    'generated::noUgUXXAmFFwqlp4' => 
    array (
      'methods' => 
      array (
        0 => 'GET',
        1 => 'HEAD',
      ),
      'uri' => 'errors/404',
      'action' => 
      array (
        'middleware' => 
        array (
          0 => 'web',
          1 => 'admin_login',
        ),
        'uses' => 'O:55:"Laravel\\SerializableClosure\\UnsignedSerializableClosure":1:{s:12:"serializable";O:46:"Laravel\\SerializableClosure\\Serializers\\Native":5:{s:3:"use";a:0:{}s:8:"function";s:59:"function ()
    {
        return \\view(\'errors.500\');
    }";s:5:"scope";s:37:"Illuminate\\Routing\\RouteFileRegistrar";s:4:"this";N;s:4:"self";s:32:"0000000000000a190000000000000000";}}',
        'namespace' => NULL,
        'prefix' => '',
        'where' => 
        array (
        ),
        'as' => 'generated::noUgUXXAmFFwqlp4',
      ),
      'fallback' => false,
      'defaults' => 
      array (
      ),
      'wheres' => 
      array (
      ),
      'bindingFields' => 
      array (
      ),
      'lockSeconds' => NULL,
      'waitSeconds' => NULL,
      'withTrashed' => false,
    ),
  ),
)
);
