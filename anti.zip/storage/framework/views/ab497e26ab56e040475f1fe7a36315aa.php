<!DOCTYPE html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact " dir="ltr"
    data-theme="theme-default" data-assets-path="../../assets/" data-template="vertical-menu-template">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Property Listing - Wizard Examples | Vuexy - Bootstrap Admin
        Template</title>

    <meta name="description" content="Start your development with a Dashboard for Bootstrap 5" />
    <meta name="keywords" content="dashboard, bootstrap 5 dashboard, bootstrap 5 design, bootstrap 5">
    <!-- Canonical SEO -->
    <link rel="canonical" href="https://1.envato.market/vuexy_admin">

    <!-- ? PROD Only: Google Tag Manager (Default ThemeSelection: GTM-5DDHKGP, PixInvent: GTM-5J3LMKC) -->
    <script>
        (function(w, d, s, l, i) {
            w[l] = w[l] || [];
            w[l].push({
                'gtm.start': new Date().getTime(),
                event: 'gtm.js'
            });
            var f = d.getElementsByTagName(s)[0],
                j = d.createElement(s),
                dl = l != 'dataLayer' ? '&l=' + l : '';
            j.async = true;
            j.src =
                '../../../../www.googletagmanager.com/gtm5445.html?id=' + i + dl;
            f.parentNode.insertBefore(j, f);
        })(window, document, 'script', 'dataLayer', 'GTM-5J3LMKC');
    </script>
    <!-- End Google Tag Manager -->

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon"
        href="https://demos.pixinvent.com/vuexy-html-admin-template/assets/img/favicon/favicon.ico" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;1,300;1,400;1,500;1,600;1,700&amp;ampdisplay=swap"
        rel="stylesheet">

    <!-- Icons -->
    <link rel="stylesheet" href="../../assets/vendor/fonts/fontawesome.css" />
    <link rel="stylesheet" href="../../assets/vendor/fonts/tabler-icons.css" />
    <link rel="stylesheet" href="../../assets/vendor/fonts/flag-icons.css" />

    <!-- Core CSS -->
    <link rel="stylesheet" href="../../assets/vendor/css/rtl/core.css" class="template-customizer-core-css" />
    <link rel="stylesheet" href="../../assets/vendor/css/rtl/theme-default.css" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="../../assets/css/demo.css" />

    <!-- Vendors CSS -->
    <link rel="stylesheet" href="../../assets/vendor/libs/node-waves/node-waves.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/typeahead-js/typeahead.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/bs-stepper/bs-stepper.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/select2/select2.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/tagify/tagify.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/flatpickr/flatpickr.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/%40form-validation/umd/styles/index.min.css" />
    <link rel="stylesheet" href="../../assets/vendor/libs/select2/select2.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css"
    integrity="sha512-6S2HWzVFxruDlZxI3sXOZZ4/eJ8AcxkQH1+JjSe/ONCEqR9L4Ysq5JdT5ipqtzU7WHalNwzwBv+iE51gNHJNqQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Page CSS -->

    <!-- Helpers -->
    <script src="../../assets/vendor/js/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="../../assets/vendor/js/template-customizer.js"></script>
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    <script src="../../assets/js/config.js"></script>

</head>

<body>

    <!-- ?PROD Only: Google Tag Manager (noscript) (Default ThemeSelection: GTM-5DDHKGP, PixInvent: GTM-5J3LMKC) -->
    <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-5DDHKGP" height="0" width="0"
            style="display: none; visibility: hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">

            <!-- Menu -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">

                <!-- Navbar -->
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Navbar -->

                <!-- Content wrapper -->
                <div class="content-wrapper">

                    <!-- Content -->

                    <div class="container-xxl flex-grow-1 container-p-y">

                        <h4 class="py-3 mb-4">
                            <span class="text-muted fw-light">Booking/</span>
                            Create new
                        </h4>

                        <!-- Property Listing Wizard -->
                        <div id="wizard-property-listing" class="bs-stepper vertical mt-2">
                            <div class="bs-stepper-header">
                                <div class="step" data-target="#personal-details">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-circle"><i class="ti ti-users ti-sm"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Order Information</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"></div>
                                <div class="step" data-target="#property-details">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-circle"><i class="ti ti-home ti-sm"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Shipping Information</span>
                                        </span>
                                    </button>
                                </div>
                                <div class="line"></div>
                                <div class="step" data-target="#property-features">
                                    <button type="button" class="step-trigger">
                                        <span class="bs-stepper-circle"><i class="ti ti-bookmarks ti-sm"></i></span>
                                        <span class="bs-stepper-label">
                                            <span class="bs-stepper-title">Item Information</span>

                                        </span>
                                    </button>
                                </div>
                                
                            </div>
                            <div class="bs-stepper-content">
                                <form id="wizard-property-listing-form" onSubmit="return false" action="" method="post">

                                    <!-- Personal Details -->
                                    <div id="personal-details" class="content">
                                        <div class="row g-3">
                                            <div class="col-12">

                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFirstName">Order Number</label>
                                                <input type="text" id="plFirstName" name="order_number"
                                                    class="form-control" placeholder="Order Number" value="<?php echo e(strtoupper(Str::random(8))); ?>

                                                    " readonly />
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plLastName">Order Type</label>
                                                <select name="order_type" class="form-control">
                                                    <option selected disabled>Order Type</option>
                                                    <option value="Air">Air</option>
                                                    <option value="Surface">Surface</option>
                                                    <option value="Same Day">Same Day</option>
                                                </select>
                                            </div>

                                            <div class="col-12 d-flex justify-content-between mt-4">
                                                <button type="button" class="btn btn-label-secondary btn-prev" disabled> <i
                                                        class="ti ti-arrow-left ti-xs me-sm-1 me-0"></i>
                                                    <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                </button>
                                                <button type="button" class="btn btn-primary btn-next"> <span
                                                        class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                                                    <i class="ti ti-arrow-right ti-xs"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Property Details -->
                                    <div id="property-details" class="content">
                                        <div class="row g-3">

                                            <div class="col-sm-6">
                                                <label for="select2Basic" class="form-label">Clients</label>
                                                <select name="client" id="select2Basic"
                                                    class="select2 form-select form-select-lg"
                                                    data-allow-clear="true">
                                                    <option selected disabled>Search For
                                                        Clients</option>
                                                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val->id); ?>">
                                                            <?php echo e($val->first_name); ?>

                                                            <?php echo e($val->last_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="select2Basic" class="form-label">WareHouse</label>
                                                <select name="warehouse" id="select2Basics"
                                                    class="select2 form-select form-select-lg"
                                                    data-allow-clear="true">
                                                    <option selected disabled>Search For
                                                        Clients</option>
                                                    <?php $__currentLoopData = $client; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val->id); ?>">
                                                            <?php echo e($val->first_name); ?>

                                                            <?php echo e($val->last_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <label for="select2Basics" class="form-label">Couriers</label>
                                                <select name="courier" id="select2Basicss"
                                                    class="select2 form-select form-select-lg"
                                                    data-allow-clear="true">
                                                    <option selected disabled>Search For
                                                        Courier</option>
                                                    <?php $__currentLoopData = $courier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($val->id); ?>">
                                                            <?php echo e($val->courier_display_name); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plState">Customer Name</label>
                                                <input type="text" id="plState" name="customer_name"
                                                    class="form-control" placeholder="Customer Name" />
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plCity">Addres 1</label>
                                                <textarea name="addres_1" id="" cols="30" rows="4" class="form-control"></textarea>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plCity">Addres 2</label>
                                                <textarea name="addres_2" id="" cols="30" rows="4" class="form-control"></textarea>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plCity">City</label>
                                                <input type="text" name="city" class="form-control" placeholder="City">
                                             </div>
                                             <div class="col-sm-6">
                                                <label class="form-label" for="plCity">Pin Code</label>
                                                <input type="text" name="pincode" class="form-control" placeholder="Pin Code">
                                             </div>
                                             <div class="col-sm-6">
                                                <label class="form-label" for="plCity">Contact Number</label>
                                                <input type="text" name="number" class="form-control" placeholder="Contact Number">
                                             </div>
                                             <div class="col-sm-6">
                                                <label class="form-label" for="plCity">Alternate Number</label>
                                                <input type="text" name="alternate_number" class="form-control" placeholder="Alternate Number">
                                             </div>

                                            <div class="col-12 d-flex justify-content-between mt-4">
                                                <button type="button" class="btn btn-label-secondary btn-prev"> <i
                                                        class="ti ti-arrow-left ti-xs me-sm-1 me-0"></i>
                                                    <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                </button>
                                                <button type="button" class="btn btn-primary btn-next"> <span
                                                        class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                                                    <i class="ti ti-arrow-right ti-xs"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Property Features -->
                                    <div id="property-features" class="content">
                                        <div class="row g-3">
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plBedrooms">Payment Mode</label>

                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="payment_mode" id="plCommonAreaRadioYes" value="cod" checked>
                                                    <label class="form-check-label"
                                                        for="plCommonAreaRadioYes">COD</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="payment_mode" id="plCommonAreaRadioNo" value="Prepaid">
                                                    <label class="form-check-label"
                                                        for="plCommonAreaRadioNo">Prepaid</label>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFloorNo">Order Date</label>
                                                <input type="date" id="plFloorNo" name="order_date"
                                                    class="form-control" placeholder="12" />
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plBathrooms">Item SKU</label>
                                                <input type="text" id="plBathrooms" name="item_sku"
                                                    class="form-control" placeholder="Item SKU" />
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plBathrooms">Item Name</label>
                                                <input type="text" id="plBathrooms" name="item_name"
                                                    class="form-control" placeholder="Item Name" />
                                            </div>
                                            <div class="col-lg-6">
                                                <label class="form-label" for="plFurnishingDetails">Item Height</label>
                                                <input   name="item_height"
                                                    class="form-control" placeholder="Item Height"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Item Lenght</label>
                                                <input id="plFurnishingDetails" name="item_lenght"
                                                    class="form-control" placeholder="Item Lenght"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Item Width</label>
                                                <input id="plFurnishingDetails" name="item_width"
                                                    class="form-control" placeholder="Item Width"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Item Weight</label>
                                                <input id="plFurnishingDetails" name="item_weight"
                                                    class="form-control" placeholder="Item Weight"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Item Quantity</label>
                                                <input id="plFurnishingDetails" name="item_quantity"
                                                    class="form-control" placeholder="Item Quantity"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Item Price</label>
                                                <input id="plFurnishingDetails" name="item_price"
                                                    class="form-control" placeholder="Item Price"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">COD Due</label>
                                                <input id="plFurnishingDetails" name="code_due"
                                                    class="form-control" placeholder="COD Due"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Origin Pincode</label>
                                                <input id="plFurnishingDetails" name="origin_pincode"
                                                    class="form-control" placeholder="Origin Pincode"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">Weight</label>
                                                <input id="plFurnishingDetails" name="weight"
                                                    class="form-control" placeholder="Weight"
                                                    >
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plFurnishingDetails">EDD</label>
                                                <input type="date" id="plFurnishingDetails" name="edd"
                                                    class="form-control" placeholder="EDD"
                                                    >
                                            </div>
                                            <div class="col-12 d-flex justify-content-between mt-4">
                                                <button type="button" class="btn btn-label-secondary btn-prev"> <i
                                                        class="ti ti-arrow-left ti-xs me-sm-1 me-0"></i>
                                                    <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                </button>
                                                <button type="submit" class="btn btn-success btn-submit btn-next"><span
                                                    class="align-middle d-sm-inline-block d-none me-sm-1">Submit</span><i
                                                    class="ti ti-check ti-xs"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Property Area -->
                                    <div id="property-area" class="content">
                                        <div class="row g-3">
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plTotalArea">Total Area</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plTotalArea"
                                                        name="plTotalArea" placeholder="1000"
                                                        aria-describedby="pl-total-area">
                                                    <span class="input-group-text" id="pl-total-area">sq-ft</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plCarpetArea">Carpet
                                                    Area</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plCarpetArea"
                                                        name="plCarpetArea" placeholder="800"
                                                        aria-describedby="pl-carpet-area">
                                                    <span class="input-group-text" id="pl-carpet-area">sq-ft</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plPlotArea">Plot Area</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plPlotArea"
                                                        name="plPlotArea" placeholder="800"
                                                        aria-describedby="pl-plot-area">
                                                    <span class="input-group-text" id="pl-plot-area">sq-yd</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plAvailableFrom">Available
                                                    From</label>
                                                <input type="text" id="plAvailableFrom" name="plAvailableFrom"
                                                    class="form-control flatpickr" placeholder="YYYY-MM-DD" />
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label">Possession Status</label>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="plPossessionStatus" id="plUnderConstruction" checked>
                                                    <label class="form-check-label" for="plUnderConstruction">Under
                                                        Construction</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="plPossessionStatus" id="plReadyToMoveRadio">
                                                    <label class="form-check-label" for="plReadyToMoveRadio">Ready to
                                                        Move</label>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label">Transaction Type</label>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="plTransectionType" id="plNewProperty" checked>
                                                    <label class="form-check-label" for="plNewProperty">New
                                                        Property</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="plTransectionType" id="plResaleProperty">
                                                    <label class="form-check-label"
                                                        for="plResaleProperty">Resale</label>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label">Is Property Facing Main
                                                    Road?</label>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="plRoadFacingRadio" id="plRoadFacingRadioYes" checked>
                                                    <label class="form-check-label"
                                                        for="plRoadFacingRadioYes">Yes</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="plRoadFacingRadio" id="plRoadFacingRadioNo">
                                                    <label class="form-check-label"
                                                        for="plRoadFacingRadioNo">No</label>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label">Gated Colony?</label>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="plGatedColonyRadio" id="plGatedColonyRadioYes" checked>
                                                    <label class="form-check-label"
                                                        for="plGatedColonyRadioYes">Yes</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="plGatedColonyRadio" id="plGatedColonyRadioNo">
                                                    <label class="form-check-label"
                                                        for="plGatedColonyRadioNo">No</label>
                                                </div>
                                            </div>
                                            <div class="col-12 d-flex justify-content-between mt-4">
                                                <button class="btn btn-label-secondary btn-prev"> <i
                                                        class="ti ti-arrow-left ti-xs me-sm-1 me-0"></i>
                                                    <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                </button>
                                                <button class="btn btn-primary btn-next"> <span
                                                        class="align-middle d-sm-inline-block d-none me-sm-1">Next</span>
                                                    <i class="ti ti-arrow-right ti-xs"></i></button>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Price Details -->
                                    <div id="price-details" class="content">
                                        <div class="row g-3">
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plExpeactedPrice">Expected
                                                    Price</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plExpeactedPrice"
                                                        name="plExpeactedPrice" placeholder="25,000"
                                                        aria-describedby="pl-expeacted-price">
                                                    <span class="input-group-text" id="pl-expeacted-price">$</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plPriceSqft">Price per
                                                    Sqft</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plPriceSqft"
                                                        name="plPriceSqft" placeholder="500"
                                                        aria-describedby="pl-price-sqft">
                                                    <span class="input-group-text" id="pl-price-sqft">$</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block"
                                                    for="plMaintenenceCharge">Maintenance Charge</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control"
                                                        id="plMaintenenceCharge" name="plMaintenenceCharge"
                                                        placeholder="50" aria-describedby="pl-mentenence-charge">
                                                    <span class="input-group-text" id="pl-mentenence-charge">$</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label" for="plMaintenencePer">Maintenance</label>
                                                <select id="plMaintenencePer" name="plMaintenencePer"
                                                    class="form-select">
                                                    <option value="1" selected>Monthly</option>
                                                    <option value="2">Quarterly</option>
                                                    <option value="3">Yearly</option>
                                                    <option value="3">One-time</option>
                                                    <option value="3">Per sqft. Monthly</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plBookingAmount">Booking/Token
                                                    Amount</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plBookingAmount"
                                                        name="plBookingAmount" placeholder="250"
                                                        aria-describedby="pl-booking-amount">
                                                    <span class="input-group-text" id="pl-booking-amount">$</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label d-block" for="plOtherAmount">Other
                                                    Amount</label>
                                                <div class="input-group input-group-merge">
                                                    <input type="number" class="form-control" id="plOtherAmount"
                                                        name="plOtherAmount" placeholder="500"
                                                        aria-describedby="pl-other-amount">
                                                    <span class="input-group-text" id="pl-other-amount">$</span>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label">Show Price as</label>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="radio"
                                                        name="plShowPriceRadio" id="plNagotiablePrice" checked>
                                                    <label class="form-check-label"
                                                        for="plNagotiablePrice">Negotiable</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="radio"
                                                        name="plShowPriceRadio" id="plCallForPrice">
                                                    <label class="form-check-label" for="plCallForPrice">Call for
                                                        Price</label>
                                                </div>
                                            </div>
                                            <div class="col-sm-6">
                                                <label class="form-label">Price includes</label>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="checkbox"
                                                        name="plCarParking" id="plCarParking">
                                                    <label class="form-check-label" for="plCarParking">Car
                                                        Parking</label>
                                                </div>
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox"
                                                        name="plClubMembership" id="plClubMembership">
                                                    <label class="form-check-label" for="plClubMembership">Club
                                                        Membership</label>
                                                </div>
                                            </div>
                                            <div class="col-md-12">
                                                <div class="form-check">
                                                    <input class="form-check-input" type="checkbox"
                                                        name="plOtherCharges" id="plOtherCharges">
                                                    <label class="form-check-label" for="plOtherCharges">Stamp Duty &
                                                        Registration
                                                        charges
                                                        excluded.</label>
                                                </div>
                                            </div>
                                            <div class="col-12 d-flex justify-content-between mt-4">
                                                <button class="btn btn-label-secondary btn-prev"> <i
                                                        class="ti ti-arrow-left ti-xs me-sm-1 me-0"></i>
                                                    <span class="align-middle d-sm-inline-block d-none">Previous</span>
                                                </button>
                                                <button class="btn btn-success btn-submit btn-next"><span
                                                        class="align-middle d-sm-inline-block d-none me-sm-1">Submit</span><i
                                                        class="ti ti-check ti-xs"></i></button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <!--/ Property Listing Wizard -->

                    </div>
                    <!-- / Content -->

                    <!-- Footer -->
                    <footer class="content-footer footer bg-footer-theme">
                        <div class="container-xxl">
                            <div
                                class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
                                <div>
                                    ©
                                    <script>
                                        document.write(new Date().getFullYear())
                                    </script>, made with ❤️ by <a href="https://pixinvent.com/"
                                        target="_blank" class="fw-medium">Pixinvent</a>
                                </div>
                                <div class="d-none d-lg-inline-block">

                                    <a href="https://themeforest.net/licenses/standard" class="footer-link me-4"
                                        target="_blank">License</a>
                                    <a href="https://1.envato.market/pixinvent_portfolio" target="_blank"
                                        class="footer-link me-4">More
                                        Themes</a>

                                    <a href="https://demos.pixinvent.com/vuexy-html-admin-template/documentation/"
                                        target="_blank" class="footer-link me-4">Documentation</a>

                                    <a href="https://pixinvent.ticksy.com/" target="_blank"
                                        class="footer-link d-none d-sm-inline-block">Support</a>

                                </div>
                            </div>
                        </div>
                    </footer>
                    <!-- / Footer -->

                    <div class="content-backdrop fade"></div>
                </div>
                <!-- Content wrapper -->
            </div>
            <!-- / Layout page -->
        </div>

        <!-- Overlay -->
        <div class="layout-overlay layout-menu-toggle"></div>

        <!-- Drag Target Area To SlideIn Menu On Small Screens -->
        <div class="drag-target"></div>

    </div>
    <!-- / Layout wrapper -->


    <script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('wizard-property-listing-form').addEventListener('submit', function(e) {
                e.preventDefault();

                var csrfToken = document.head.querySelector('meta[name="csrf-token"]').content;
                var formData = new FormData(this);

                fetch("<?php echo e(url('manual-booking')); ?>", {
                        method: "POST",
                        body: formData,
                        headers: {
                            'X-CSRF-TOKEN': csrfToken,
                        },
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.status === 'success') {

                            toastr.options = {
                                "closeButton": true,

                            };
                            toastr.success(data.message);
                            setTimeout(function() {

                                window.location.href = '<?php echo e(url('all-booking')); ?>';
                            }, 2000);
                        } else {
                            toastr.options = {
                                "closeButton": true,

                            };
                            toastr.warning(data.message);
                            setTimeout(function() {

                                // window.location.href='<?php echo e(url('')); ?>';
                            }, 4000);
                        }
                    })


            });
        });
    </script>


    <!-- Core JS -->
    <!-- build:js assets/vendor/js/core.js -->

    <script src="../../assets/vendor/libs/jquery/jquery.js"></script>
    <script src="../../assets/vendor/libs/popper/popper.js"></script>
    <script src="../../assets/vendor/js/bootstrap.js"></script>
    <script src="../../assets/vendor/libs/node-waves/node-waves.js"></script>
    <script src="../../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="../../assets/vendor/libs/hammer/hammer.js"></script>
    <script src="../../assets/vendor/libs/i18n/i18n.js"></script>
    <script src="../../assets/vendor/libs/typeahead-js/typeahead.js"></script>
    <script src="../../assets/vendor/js/menu.js"></script>

    <!-- endbuild -->

    <!-- Vendors JS -->
    <script src="../../assets/vendor/libs/cleavejs/cleave.js"></script>
    <script src="../../assets/vendor/libs/cleavejs/cleave-phone.js"></script>
    <script src="../../assets/vendor/libs/bs-stepper/bs-stepper.js"></script>
    <script src="../../assets/vendor/libs/select2/select2.js"></script>
    <script src="../../assets/vendor/libs/tagify/tagify.js"></script>
    <script src="../../assets/vendor/libs/flatpickr/flatpickr.js"></script>
    <script src="../../assets/vendor/libs/%40form-validation/umd/bundle/popular.min.js"></script>
    <script src="../../assets/vendor/libs/%40form-validation/umd/plugin-bootstrap5/index.min.js"></script>
    <script src="../../assets/vendor/libs/%40form-validation/umd/plugin-auto-focus/index.min.js"></script>

    <!-- Main JS -->
    <script src="../../assets/js/main.js"></script>

    <!-- Page JS -->
    <script src="../../assets/js/forms-selects.js"></script>
    <script src="../../assets/js/wizard-ex-property-listing.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js" integrity="sha512-lbwH47l/tPXJYG9AcFNoJaTMhGvYWhVM9YI43CT+uteTRRaiLCui8snIgyAN8XWgNjNhCqlAUdzZptso6OCoFQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

</body>

<!-- Mirrored from demos.pixinvent.com/vuexy-html-admin-template/html/vertical-menu-template/wizard-ex-property-listing.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 20 Dec 2023 06:09:23 GMT -->

</html>

<!-- beautify ignore:end -->
<?php /**PATH F:\anti air\resources\views/booking.blade.php ENDPATH**/ ?>