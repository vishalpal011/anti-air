<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>GassGuzzlers</title>
    <style type="text/css">
        body {
            margin: 0;
            background-color: #cccccc;
        }
        table {
            border-spacing: 0;
        }
        td {
            padding: 0;
        }
        img {
            border: 0;
        }
        .wrapper {
            width: 100%;
            table-layout: fixed;
            background-color: #cccccc;
            padding-bottom: 60px;
        }
        .main {
            background-color: #e4e4e4;
            margin: 0 auto;
            width: 100%;
            max-width: 850px;
            border-spacing: 0;
            font-family: sans-serif;
            color: #4a4a4a;
        }
        .one-columns {
            text-align: center;
            font-size: 0;
        }
        .one-columns .column {
            width: 100%;
            max-width: 100%;
        }
        .p-text {
            line-height: 18px;
        }
        .button {
            color: #ffffff;
            background-color: #f7931b;
            padding: 10px 30px;
            font-size: 15px;
            text-decoration: none;
            border-radius: 10px;
        }
        .footer-icon {
            padding-top: 10px;
        }
        .footer-icon a {
            color: #ffffff;
        }
        @media screen and (min-width: 275px) and (max-width: 768px) {
            .p-text {
                line-height: 20px;
            }
        }

    </style>
</head>
<body>
<center class="wrapper">
    <table class="main" width="100%">

        <!-- BLUE BORDER -->
        <!-- <tr>
            <td height="8" style="background-color: #ffc107;"></td>
        </tr> -->
        <!-- LOGO SECTION -->
        <tr>
            <td>
                <table width="100%" style="background-color: #000000; padding: 40px 0;">
                    <tr>
                        <td class="one-columns">
                            <table class="column">
                                <tr>
                                    <td>
                                        <a href="https://beta.gasguzzlrs.com/"><img src="https://api.gasguzzlrs.com/images/lightmode-logo.gif" alt="logo" width="180px"></a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <!-- BANNER IMAGE -->
        <tr>
            <td style="padding: 5px 0 0px;">
                <table width="100%">
                    <tr>
                        <td style="padding: 15px 30px; text-align: center;">
                            <p style="font-size: 20px; font-weight: bold;"><strong style="color: #000;">Welcome to Gas Guzzlrs</strong></p>
                            <img src="https://api.gasguzzlrs.com/images/bgImg_02.jpg" alt="banner" style="max-width: 775px;">
                        </td>
                    </tr>
                </table>
            </td>
        </tr>

        <!-- TITLE, TEXT & BUTTON -->
        <tr>
            <td style="padding: 0 10px 20px;">
                <table width="100%">
                    <tr>
                        <td style="padding: 0px 30px;">
                            <p style="padding-top: 5px; font-weight: 700;">Hi : <?php echo e(\Illuminate\Support\Str::words($first_name,1,'')); ?></span> ,</p>

                            <div style="padding-top: 5px;" class="p-text">

                                <span><b>Name</b>: <?php echo e(\Illuminate\Support\Str::words($first_name,1,'')); ?></span><br>

                                <span><b>Email</b>: <?php echo e(\Illuminate\Support\Str::words($email,1,'')); ?></span>

                            </div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>



        <!-- TWO COLUMN SECTION -->
        <tr>
            <td style="padding: 5px 0 20px; text-align: center;">
                <table width="100%">
                    <tr>
                        <td style="padding: 15px 30px;">
                            <div style="line-height: 5px;">
                                <p style="font-size: 12px;">Questions? Please email <a href="#" style="text-decoration: none; color: #f7931b;">sales@gasguzzlrs.com</a></p>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
        <!-- FOOTER SECTION -->
        <tr>
            <td>
                <table width="100%" style="background-color: #000000; padding: 40px 0;">
                    <tr>
                        <td style="text-align: center; color: #ffffff; font-size: 12px; line-height: 5px; opacity: 0.7;">
                            <p>&copy; 2023 GasGuzzlrs</p>
                            <p>1300 17th St. San Francisco, CA 94107To</p>
                            <p>unsubscribe from these updates, <a href="#" style="text-decoration: none; color: #f7931b;">click here.</a></p>
                            <p>To manage your email preferences, <a href="#" style="text-decoration: none; color: #f7931b;">click here</a></p>
                        </td>
                    </tr>
                    <tr>
                        <td style="text-align: center;">
                            <div class="footer-icon">
                                <a href="#" class="social-icon"><img src="https://api.gasguzzlrs.com/images/instagram.png" alt="instagram"></a>
                                <a href="#" class="social-icon"><img src="https://api.gasguzzlrs.com/images/facebook.png" alt="facebook"></a>
                                <a href="#" class="social-icon"><img src="https://api.gasguzzlrs.com/images/twitter.png" alt="twitter"></a>
                                <a href="#" class="social-icon"><img src="https://api.gasguzzlrs.com/images/youtube.png" alt="youtube"></a>
                            </div>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</center>

<script src="https://kit.fontawesome.com/cea02e4233.js" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH E:\anti air\resources\views/Emails/Client_email.blade.php ENDPATH**/ ?>