<!DOCTYPE html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact " dir="ltr"
    data-theme="theme-default" data-assets-path="../../assets/" data-template="vertical-menu-template">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Dashboard - Analytics | Vuexy - Bootstrap Admin Template</title>


    <meta name="description" content="Start your development with a Dashboard for Bootstrap 5" />
    <meta name="keywords" content="dashboard, bootstrap 5 dashboard, bootstrap 5 design, bootstrap 5">

    <?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<style>
    .custom-option-icon .custom-option-content {
        text-align: center;
        padding: 6px;
    }

</style>

<body>

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">

            <!-- Menu -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Navbar -->
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">
                    <h5 class="py-3 mb-2">
                            <span class="text-muted fw-light">AWB Stocks /</span> Create Stocks
                    </h5>
                        <form id="aws" method="POST">
                        <div class="row">

                                <div class="col-md-10">
                                    <div class="col" data-select2-id="23">
                                        <!-- <h6> Create Stocks </h6> -->
                                        <div class="accordion" id="collapsibleSection">
                                            <div class="card accordion-item active" data-select2-id="22">
                                                <h2 class="accordion-header" id="headingDeliveryAddress">
                                                    <button type="button" class="accordion-button">Delivery Address
                                                    </button>
                                                </h2>


                                                    <div id="collapseDeliveryAddress"
                                                        class="accordion-collapse collapse show"
                                                        data-bs-parent="#collapsibleSection"
                                                        data-select2-id="collapseDeliveryAddress" style="">
                                                        <div class="accordion-body" data-select2-id="21">
                                                            <div class="row g-3" data-select2-id="20">
                                                                <div class="col-md-6">
                                                                    <label class="form-label" for="collapsible-fullname">
                                                                        Waybill Counts
                                                                    </label>
                                                                    <input type="number" id="collapsible-fullname"
                                                                        class="form-control" name="aws_count" placeholder="Waybill Counts" required>
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <label class="form-label" for="collapsible-phone">
                                                                        Search User</label>
                                                                    <input type="text" id="userInput" name="user_input"
                                                                        class="form-control phone-mask"
                                                                        placeholder="Search by code or name" required>
                                                                </div>


                                                                <div class="col-md-6">
                                                                    <label class="form-label"
                                                                        for="collapsible-pincode">Waybill
                                                                        Type</label>
                                                                    <input type="text" id="collapsible-pincode"
                                                                        class="form-control" name="waybill_type" placeholder="Waybill Type" required>
                                                                </div>
                                                                <div class="col mt-2 pt-4">
                                                                    <div class="form-check form-check-inline">
                                                                        <!-- <input name="cod"
                                                                            class="form-check-input" type="radio" value="on">
                                                                        <label class="form-check-label"
                                                                            for="collapsible-address-type-home">COD</label> -->
                                                                            <input name="cod" class="form-check-input" type="checkbox" value="on" id="cod">
                                                                            <label class="form-check-label" for="cod">
                                                                                COD
                                                                            </label>
                                                                    </div>
                                                                    <div class="form-check form-check-inline">
                                                                        <!-- <input name="prepaid"
                                                                            class="form-check-input" type="radio" value="on">
                                                                        <label class="form-check-label"
                                                                            for="collapsible-address-type-office">Prepaid</label> -->
                                                                            <input name="prepaid" class="form-check-input" type="checkbox" value="on" id="Prepaid">
                                                                            <label class="form-check-label" for="Prepaid">
                                                                            Prepaid
                                                                            </label>
                                                                    </div>
                                                                    <div class="form-check form-check-inline">
                                                                        <!-- <input name="rvp"
                                                                            class="form-check-input" type="radio" value="on">
                                                                        <label class="form-check-label"
                                                                            for="collapsible-address-type-office">RVP</label> -->
                                                                            <input name="rvp" class="form-check-input" type="checkbox" value="on" id="RVP">
                                                                            <label class="form-check-label" for="RVP">
                                                                            RVP
                                                                            </label>
                                                                    </div>
                                                                    <div class="col-md-12 pt-5 pr-4">
                                                                        <button type="submit"
                                                                            class="btn btn-primary">Upload</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>

                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2 pt-5">
                                    <div id="card" style="display: none;">
                                        <div id="usersContainer"></div>
                                    </div>
                                </div>

                        </div>
                    </form>
                    </div>
                    <!-- / Content -->




                    <!-- Footer -->
                    <script>
                        var timeoutId;
                        document.getElementById('userInput').addEventListener('input', function(event) {
                            clearTimeout(timeoutId);

                            // Delay the AJAX request by 500 milliseconds after the user stops typing
                            timeoutId = setTimeout(function() {
                                var userInput = event.target.value;

                                // Send an AJAX request to retrieve data
                                fetch('/get-awb-users?code=' + userInput)
                                    .then(response => response.json())
                                    .then(data => {
                                        console.log(data);

                                        // Clear existing data
                                        document.getElementById('usersContainer').innerHTML = '';



                                        // Loop through each user and display their information
                                        data.data.forEach(user => {
                                            var userContainer = document.createElement('div');
                                            userContainer.className = 'user-info';

                                            userContainer.innerHTML = `
                                            <div class="col-md mb-md-0 mb-2 p-1">
                                                <div class="custom-option custom-option-icon">
                                                <label class="form-check-label custom-option-content" for="customRadioOwner">
                                                    <span class="custom-option-body">

                                                    <span class="custom-option-title">${user.name} <small>${user.code}</small></span> <input name="outline_squircle" class="form-check-input" type="radio" value="${user.code}" id="customRadioOwner">

                                                    </span>

                                                </label>
                                                </div>
                                            </div>
                                                    `;

                                            var nameId = user.nam;
                                            var codeId = user.code;

                                            document.getElementById('usersContainer').appendChild(
                                                userContainer);

                                        });

                                        document.getElementById('card').style.display = 'block';
                                    })

                            }, 500);
                        });
                    </script>
                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            document.getElementById('aws').addEventListener('submit', function(e) {
                                e.preventDefault();

                                var csrfToken = document.head.querySelector('meta[name="csrf-token"]').content;
                                var formData = new FormData(this);


                                fetch("<?php echo e(url('creat-aws-stock')); ?>", {
                                        method: "POST",
                                        body: formData,
                                        headers: {
                                            'X-CSRF-TOKEN': csrfToken,
                                        },
                                    })
                                    .then(response => response.json())
                                    .then(data => {

                                        if (data.status === 'success') {

                                            window.location.href = "<?php echo e(url('create-awb')); ?>";
                                        } else {

                                        }
                                    })

                            });
                        });
                    </script>


<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH F:\anti air\resources\views/awb-stocks.blade.php ENDPATH**/ ?>