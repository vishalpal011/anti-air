<!DOCTYPE html>

<html lang="en" class="light-style layout-navbar-fixed layout-menu-fixed layout-compact " dir="ltr"
    data-theme="theme-default" data-assets-path="../../assets/" data-template="vertical-menu-template">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport"
        content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />

    <title>Dashboard - Analytics | Vuexy - Bootstrap Admin Template</title>


    <meta name="description" content="Start your development with a Dashboard for Bootstrap 5" />
    <meta name="keywords" content="dashboard, bootstrap 5 dashboard, bootstrap 5 design, bootstrap 5">

    <?php echo $__env->make('layouts.links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Page CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.css"
        integrity="sha512-6S2HWzVFxruDlZxI3sXOZZ4/eJ8AcxkQH1+JjSe/ONCEqR9L4Ysq5JdT5ipqtzU7WHalNwzwBv+iE51gNHJNqQ=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- toster alert link -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <!-- end toster alert -->

    <!-- Helpers -->
    <script src="../../assets/vendor/js/helpers.js"></script>
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="../../assets/vendor/js/template-customizer.js"></script>
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    
</head>
<style>
    .top_rw {
        background-color: #f4f4f4;
    }

    .td_w {}

    button {
        padding: 5px 10px;
        font-size: 14px;
    }

    .invoice-box {
        max-width: 890px;
        margin: auto;
        padding: 10px;
        border: 1px solid #eee;
        box-shadow: 0 0 10px rgba(0, 0, 0, .15);
        font-size: 14px;
        line-height: 24px;
        font-family: 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
        color: #555;
    }

    .invoice-box table {
        width: 100%;
        line-height: inherit;
        text-align: left;
        border-bottom: solid 1px #ccc;
    }

    .invoice-box table td {
        padding: 5px;
        vertical-align: middle;
    }

    .invoice-box table tr td:nth-child(2) {
        text-align: right;
    }

    .invoice-box table tr.top table td {
        padding-bottom: 20px;
    }

    .invoice-box table tr.top table td.title {
        font-size: 45px;
        line-height: 45px;
        color: #333;
    }

    .invoice-box table tr.information table td {
        padding-bottom: 40px;
    }

    .invoice-box table tr.heading td {
        background: #eee;
        border-bottom: 1px solid #ddd;
        font-weight: bold;
        font-size: 12px;
    }

    .invoice-box table tr.details td {
        padding-bottom: 20px;
    }

    .invoice-box table tr.item td {
        border-bottom: 1px solid #eee;
    }

    .invoice-box table tr.item.last td {
        border-bottom: none;
    }

    .invoice-box table tr.total td:nth-child(2) {
        border-top: 2px solid #eee;
        font-weight: bold;
    }

    @media only screen and (max-width: 600px) {
        .invoice-box table tr.top table td {
            width: 100%;
            display: block;
            text-align: center;
        }

        .invoice-box table tr.information table td {
            width: 100%;
            display: block;
            text-align: center;
        }
    }

    /** RTL **/
    .rtl {
        direction: rtl;
        font-family: Tahoma, 'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;
    }

    .rtl table {
        text-align: right;
    }

    .rtl table tr td:nth-child(2) {
        text-align: left;
    }

    .hidden {
        display: none;
    }
</style>

<body>
    <script>
        <?php if(Session::has('error')): ?>
            toastr.options = {
                "closeButton": true,
                "progressBar": true
            }
            toastr.warning("<?php echo e(session('error')); ?>", {
                timeOut: 15000
            })
        <?php endif; ?>
    </script>

    <!-- Layout wrapper -->
    <div class="layout-wrapper layout-content-navbar  ">
        <div class="layout-container">

            <!-- Menu -->
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- / Menu -->

            <!-- Layout container -->
            <div class="layout-page">
                <!-- Navbar -->
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Navbar -->
                <!-- Content wrapper -->
                <div class="content-wrapper">
                    <div class="container-xxl flex-grow-1 container-p-y">

                        <h4 class="py-3 mb-2">
                            <span class="text-muted fw-light">Label /</span> Designs
                        </h4>

                        <!-- Order List Widget -->

                        <!-- Order List Table -->
                        <div class="card p-3">

                            

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="card" style="width: 18rem;">
                                        <img class="card-img-top" src="<?php echo e(url('assets/images/4x4.png')); ?>" alt="Card image cap">
                                        <div class="card-body">
                                          <p class="card-text"> 4*4 Label</p>
                                          <ul style="display: flex; list-style:none;">
                                            <li>
                                                <a href="<?php echo e(url('edit-label-4x4')); ?>">
                                                    <button class="btn btn-primary">Edit</button>
                                                </a>
                                            </li>

                                        </ul>
                                        </div>
                                      </div>

                                </div>
                                <div class="col-md-4">
                                    <div class="card" style="width: 18rem;">
                                        <img class="card-img-top" src="<?php echo e(url('assets/images/4.5.png')); ?>" alt="Card image cap">
                                        <div class="card-body">
                                          <p class="card-text">   4.5*6.25 Label</p>
                                          <ul style="display: flex; list-style:none;">
                                            <li>
                                                <a href="<?php echo e(url('edit-label-4.5x6.25')); ?>">
                                                    <button class="btn btn-primary">Edit</button>
                                                </a>
                                            </li>


                                        </ul>
                                        </div>
                                      </div>


                                </div>
                                <div class="col-md-4">
                                    <div class="card" style="width: 18rem;">
                                        <img class="card-img-top" src="<?php echo e(url('assets/images/4x6.png')); ?>" alt="Card image cap">
                                        <div class="card-body">
                                          <p class="card-text"> 4*6 Label</p>
                                          <ul style="display: flex; list-style:none;">
                                                <li>
                                                    <a href="<?php echo e(url('edit-label-4x6')); ?>">
                                                        <button class="btn btn-primary">Edit</button>
                                                    </a>
                                                </li>

                                           </ul>
                                        </div>
                                      </div>
                                 </div>
                            </div>
                            <div class="row pt-3">
                                <div class="col-md-4">
                                    <div class="card" style="width: 18rem;">
                                        <img class="card-img-top" src="<?php echo e(url('assets/images/defualt.png')); ?>" alt="Card image cap">
                                        <div class="card-body">
                                          <p class="card-text">Default Label</p>
                                          <ul style="display: flex; list-style:none;">
                                                <li>
                                                    <a href="<?php echo e(url('default')); ?>">
                                                        <button class="btn btn-primary">Edit</button>
                                                    </a>
                                                </li>

                                           </ul>
                                        </div>
                                      </div>
                                 </div>


                            </div>

                        </div>

                    </div>
                    <!-- / Content -->



                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            var toggleCheckbox = document.getElementById('customRadioIcon1');
                            var div1 = document.getElementById('div1');
                            var div2 = document.getElementById('div2');
                            var div3 = document.getElementById('div3');

                            toggleCheckbox.addEventListener('change', function() {
                                if (toggleCheckbox.checked) {
                                    // If checkbox is checked, show div1 and hide div2
                                    div1.classList.remove('hidden');
                                    div2.classList.add('hidden');
                                    div3.classList.add('hidden');
                                } else {
                                    // If checkbox is unchecked, show div2 and hide div1
                                    div2.classList.remove('hidden');
                                    div1.classList.add('hidden');
                                }
                            });
                        });
                    </script>

                    <script>
                        document.addEventListener('DOMContentLoaded', function() {
                            document.getElementById('save').addEventListener('submit', function(e) {
                                e.preventDefault();

                                var csrfToken = document.head.querySelector('meta[name="csrf-token"]').content;
                                var formData = new FormData(this);

                                alert("Are You Sure want to save this")

                                fetch("<?php echo e(url('save-label')); ?>", {
                                        method: "POST",
                                        body: formData,
                                        headers: {
                                            'X-CSRF-TOKEN': csrfToken,
                                        },
                                    })
                                    .then(response => response.json())
                                    .then(data => {
                                        console.log(data);
                                        if (data.status === 'success') {

                                            toastr.options = {
                                                "closeButton": true,
                                                "progressBar": true,
                                                "timeOut": 15000
                                            };
                                            toastr.success(data.message);
                                            setTimeout(function() {

                                                window.location.href = '<?php echo e(url('view-Courier')); ?>';
                                            }, 2500);

                                        } else {
                                            toastr.options = {
                                                "closeButton": true,
                                                "closeButton": true,
                                                "progressBar": true,
                                                "timeOut": 15000

                                            };
                                            toastr.warning(data.message);
                                            setTimeout(function() {

                                                // window.location.href='<?php echo e(url('')); ?>';
                                            }, 4000);
                                        }
                                    })

                            });
                        });
                    </script>
                    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH E:\anti air\resources\views/lable-designs.blade.php ENDPATH**/ ?>