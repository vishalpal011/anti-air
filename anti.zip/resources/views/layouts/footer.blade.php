<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl">
      <div
        class="footer-container d-flex align-items-center justify-content-between py-2 flex-md-row flex-column">
        <div>
          ©
          <script>
            document.write(new Date().getFullYear())
          </script>, made with ❤️ by <a href="https://corewave.io/" target="_blank" class="fw-medium">Corewave</a>
        </div>
        <!-- <div class="d-none d-lg-inline-block">

          <a href="https://themeforest.net/licenses/standard" class="footer-link me-4"
            target="_blank">License</a>
          <a href="https://1.envato.market/pixinvent_portfolio" target="_blank" class="footer-link me-4">More
            Themes</a>

          <a href="https://demos.pixinvent.com/vuexy-html-admin-template/documentation/" target="_blank"
            class="footer-link me-4">Documentation</a>


          <a href="https://pixinvent.ticksy.com/" target="_blank"
            class="footer-link d-none d-sm-inline-block">Support</a>

        </div> -->
      </div>
    </div>
  </footer>
  <!-- / Footer -->


  <div class="content-backdrop fade"></div>
</div>
<!-- Content wrapper -->
</div>
<!-- / Layout page -->
</div>



<!-- Overlay -->
<div class="layout-overlay layout-menu-toggle"></div>


<!-- Drag Target Area To SlideIn Menu On Small Screens -->
<div class="drag-target"></div>

</div>
<!-- / Layout wrapper -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js" integrity="sha512-eyO7tcAXXrQLgGXk4IuqHVKlA0/cL80N+ya1U6l7qNluvsOdVVotPnFIIlTvQ8l6mqhf9uR0eN/dFvJen0qiZg==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>




<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="{{url('../../assets/vendor/libs/jquery/jquery.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/popper/popper.js')}}"></script>
<script src="{{url('../../assets/vendor/js/bootstrap.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/node-waves/node-waves.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/hammer/hammer.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/i18n/i18n.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/typeahead-js/typeahead.js')}}"></script>
<script src="{{url('../../assets/vendor/js/menu.js')}}"></script>

<!-- endbuild -->

<!-- Vendors JS -->
<script src="{{url('../../assets/vendor/libs/apex-charts/apexcharts.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/swiper/swiper.js')}}"></script>
<script src="{{url('../../assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js')}}"></script>

<!-- Main JS -->
<script src="{{url('../../assets/js/main.js')}}"></script>


<!-- Page JS -->
<script src="{{url('../../assets/js/dashboards-analytics.js')}}"></script>

<script>
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'copy', 'csv', 'excel', 'pdf', 'print'
        ]
    } );
} );
</script>
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.4/toastr.min.js" integrity="sha512-lbwH47l/tPXJYG9AcFNoJaTMhGvYWhVM9YI43CT+uteTRRaiLCui8snIgyAN8XWgNjNhCqlAUdzZptso6OCoFQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>


</body>



</html>

<!-- beautify ignore:end -->
