@extends('errors.minimal')

@section('title', __('Internal Error'))
@section('code', '500')
@section('message', __('Server Error'))
